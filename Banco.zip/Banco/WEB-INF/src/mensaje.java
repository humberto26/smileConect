import javax.servlet.http.*;
import java.io.*;
import java.rmi.*;
import java.util.*;
import database.*;
import java.sql.*;


public class mensaje extends HttpServlet {

public String cifrado(String asunto, String publica)throws IOException{
	String res="";
	String[] cmd = {"encripta.sh",asunto, publica};
	Process p = Runtime.getRuntime().exec(cmd);
	BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
	res=input.readLine();

	return res;
}

public String descifrado (String asunto )throws IOException{
        String res="";
        String[] cmd = {"descifra.sh",asunto};
        Process p = Runtime.getRuntime().exec(cmd);
        BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
        res=input.readLine();

        return res;
}

public String escribir(String mensaje, String asunto)throws IOException{
	String a="";
	File archivo;
	archivo=new File("/home/SeguridadWeb/demo/WEB-INF/src/"+asunto+".txt");
	//escritura
	try{
		FileWriter w = new FileWriter(archivo);
		BufferedWriter bw = new BufferedWriter(w);
		PrintWriter wr = new PrintWriter(bw);  
	        wr.write(mensaje);//escribimos en el archivo
	//	wr.append(" - y aqui continua"); //concatenamos en el archivo sin borrar lo existente

	        //ahora cerramos los flujos de canales de datos, al cerrarlos el archivo quedará guardado con información escrita

	        //de no hacerlo no se escribirá nada en el archivo

	wr.close();

	bw.close();

	}catch(IOException e){
	
	}

	return a;	 
		
	   


}




 public void doPost(HttpServletRequest request, HttpServletResponse response)
					throws ServerException, IOException{
 
	PrintWriter out = response.getWriter();
	
	try{
		response.setContentType("text/html");
		HttpSession sesion=request.getSession(true);
		
		//int id=Integer.parseInt(request.getParameter("id"));
		String asunto=request.getParameter("asunto");
		String nombre=request.getParameter("nombre");
		String mensaje=request.getParameter("mensaje");	
		String dato=request.getParameter("datos");	
		out.println("nombre :"+ nombre);
		out.println("mensaje :"+ mensaje);
		out.println("asunto :"+ asunto);
		out.println("datos :"+ dato);
		
		
		String resultado="";
		String cifra="";
		//String publica="";
		resultado = escribir(mensaje, asunto);
		//privada = priv(nombre);
		out.println("resultado es:  "+ resultado);
		
        	//out.println("LLAVE PRIVADA   :"+privada);
        	//publica = pub(nombre);
	        out.println("\n");
		//out.println("LLAVE PUBLICA : "+publica);
		out.println("\n");
		out.println("<br>");
  		//Paso 1 registro de drive
		



 	
                String query_busca = "SELECT nombre FROM encriptar WHERE nombre = '"+nombre+"';";
		String query = "SELECT publica FROM encriptar WHERE nombre = '"+nombre+"';";
		
		
                if(  ( new db().busca( query_busca ) ) ) { //si regresa true 
	                
		
			ArrayList usuario = new db().consultaReg(query);
			Iterator ite = usuario.iterator();
			int users=0;
			String res="";
			out.println("entro al if\n");
			while(ite.hasNext()){
				users++;
				ArrayList lista=(ArrayList)ite.next();
				res=lista.get(0).toString();	
				
						
			
			}
			out.println("publica es: "+res);
			cifra = cifrado(asunto, res);
			out.println("cifrado es : "+ cifra);

			
                }
                else {
                String msg = "El usuario ya existe registrado";
                //request.getSession().setAttribute("msg",msg);
               // response.sendRedirect(request.getContextPath()+"/index.jsp");

                   }
                }
                catch(Exception e){
                out.println("ocurrio un error en "+ e);
                } 
	}      

}
