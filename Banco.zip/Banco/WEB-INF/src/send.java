import javax.servlet.http.*;
import java.io.*;
import java.rmi.*;
import java.util.*;
import database.*;
import java.sql.*;
import java.util.Date;
import encriptacion.*;

public class send extends HttpServlet {

 public void doPost(HttpServletRequest request, HttpServletResponse response)
					throws ServerException, IOException{
 
	PrintWriter out = response.getWriter();
	HttpSession session= (HttpSession) request.getSession();
 		
	
	try{
		response.setContentType("text/html");
		
		int hora;
		int segundos;
		int minutos;
		String dia, mes, annio;
								
								

			Calendar calendario = new GregorianCalendar();
			Date fecha = new Date ();
			hora =calendario.get(Calendar.HOUR);
    			minutos = calendario.get(Calendar.MINUTE);
    			segundos = calendario.get(Calendar.SECOND);

			dia =Integer.toString(calendario.get(Calendar.DATE));	
			mes = Integer.toString(calendario.get(Calendar.MONTH));
			annio = Integer.toString(calendario.get(Calendar.YEAR));


		String hour= "";
                String day =""; 
	
		String asunto=request.getParameter("asunto");
		String mensaje=request.getParameter("mensaje");	
		String receptor=request.getParameter("res");
		out.println(receptor);	
		String user=(String)session.getAttribute("user");
   		hour+=hora+":"+minutos+":"+segundos; 
		day+=dia+"/"+mes+"/"+annio;
		boolean status=true;
				
		
		
	//	out.println("mensaje :"+ mensaje);
	//	out.println("asunto :"+ asunto);
	//	out.println("enviado a  :"+ receptor);
	//	out.println("fue enviado por el usuario :"+ user );

		
		
		String resultado="";
 		String query_consulta="SELECT publica From users  WHERE nombre='"+receptor+"'; ";
                String query_busca = "SELECT* FROM mensaje;";
		//String query = "SELECT publica FROM Users WHERE login = '"+login+"';";
		//String query = "insert into mensaje(asunto,mensaje, emisor,receptor,fecha, hora, status) values('"+asunto+"','"+cifra+"','"+user+"','"+receptor+"','"+day+"','"+hour+"',"+status+");";
		if(  ( new db().busca(query_busca) ) ) { //si regresa true
		
		  ArrayList usuario = new db().consultaReg(query_consulta);
                  Iterator ite = usuario.iterator();
                        
                   out.println("entro al if\n");
                        while(ite.hasNext()){
                                 ArrayList lista=(ArrayList)ite.next();
                                resultado=lista.get(0).toString();    



                        }
			String cifra="";
			//out.println("cadena1"+resultado+"\n");
			cifra  = asimetrico.Encripta("/home/max/Documents/llaves", mensaje, resultado);	
			out.println("cifrado original"+ cifra);	
			cifra = cifra.replace('+','$');
			cifra = cifra.replace('\n','?');

			//out.println("cifrado cambiado"+ cifra);

			String query_alta = "insert into mensaje (asunto,mensaje, emisor,receptor,fecha, hora, status) values('"+asunto+"','"+cifra+"','"+user+"','"+receptor+"','"+day+"','"+hour+"',"+status+");";
 			new db().execQuery(query_alta);
 			response.sendRedirect("home.jsp");


                }
                else {
                String msg = "El registro no ha sido corrcto";
                request.getSession().setAttribute("msg",msg);
               // response.sendRedirect(request.getContextPath()+"/index.jsp");

                   }

 	 		
	                

	







     /*          
		
			ArrayList usuario = new db().consultaReg(query);
			Iterator ite = usuario.iterator();
			int users=0;
			String res="";
			out.println("entro al if\n");
			while(ite.hasNext()){
				users++;
				ArrayList lista=(ArrayList)ite.next();
				res=lista.get(0).toString();	
				
						
			
			}
			out.println("publica es: "+res);
			
			new db().execQuery( query_alta );
				
			
*/
			
             //   }
         //       else {
           //     String msg = "El usuario ya existe registrado";
                //request.getSession().setAttribute("msg",msg);
               // response.sendRedirect(request.getContextPath()+"/index.jsp");
		//	}
                   
                }
                catch(Exception e){
                out.println("ocurrio un error en "+ e);
                } 
	}      

}
