import javax.servlet.http.*;
import java.io.*;
import java.rmi.*;
import java.sql.*;
import java.util.*;
import database.*;


public class insertar extends HttpServlet{
	
	

  public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServerException, IOException{

	
	 PrintWriter out = response.getWriter();
	 HttpSession session=request.getSession(true);
	try{
		response.setContentType("text/html");
	
		String rfc = request.getParameter("rfc");
		String nombre = request.getParameter("nombre");
		String pass = request.getParameter("pass");
		String domicilio = request.getParameter("domicilio");
		String horario = request.getParameter("horario");
	  String dia_servicio = request.getParameter("dia_servicio");
		String tipo = request.getParameter("tipo");



		String query_alta = "insert into empresa values('"+rfc+"','"+nombre+"','"+domicilio+"','"+horario+"','"+dia_servicio+"','"+tipo+"','"+pass+"'"+")";
		
		String query_busca = "SELECT rfc FROM empresa WHERE rfc = '"+rfc+"';";

		out.println(query_busca);

		if( ! ( new db().busca( query_busca ) ) ) { //si regresa true
		new db().execQuery( query_alta );
		response.sendRedirect(request.getContextPath()+"/home.jsp");
		out.println("hola");
		}
		else {
		String msg = "El login ya esta registrado, intenta con otro";
		session.setAttribute("msg",msg);
		response.sendRedirect("registro.jsp");


		   }
		}
		catch(Exception e){
		out.println("ocurrio un error en "+ e);
		}

  
	}
}
