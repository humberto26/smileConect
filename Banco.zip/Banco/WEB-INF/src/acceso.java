import javax.servlet.http.*;
import java.io.*;
import java.rmi.*;
import java.sql.*;
import java.util.*;
import database.*;


public class acceso extends HttpServlet {

 public void doPost (HttpServletRequest request,HttpServletResponse response) 

					throws ServerException,IOException{

        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession(true);

	try{
                response.setContentType("text/html");

                //PrintWriter out = response.getWriter();

                 
//		sesion.setAttribute("email", request.getParameter("email"));

                // Se reciben los valores del formulario1

                String rfc=request.getParameter("rfc");
                String password=request.getParameter("password");
	
		//out.println(login);
		//out.println(password);
		//out.println("la session es de : "+sesion);
		String Banco="Banco de alimentos";
		String busca ="SELECT *  FROM empresa WHERE rfc = '" + rfc +"' and password ='"+password+"';";
		String user="";
//		out.println(busca);
		 if(  (new  db().busca(busca)))
		
		 { //si regresa true 
	                
		
			ArrayList usuario = new db().consultaReg(busca);
			Iterator ite = usuario.iterator();
		
			while(ite.hasNext()){

				ArrayList lista=(ArrayList)ite.next();
				user=lista.get(1).toString();
				
				

				//response.sendRedirect("home.jsp");	
				
						
			}
			
			if (user.equals(Banco)) {
			
						out.println(user);
						session.setAttribute("user",user);
				response.sendRedirect("home.jsp");
		
				
			}else
			{
				
				out.println(user);
				session.setAttribute("user",user);
				response.sendRedirect("index.jsp");
			}
		
	
              // String query = "SELECT publica FROM encriptar WHERE nombre = '"+nombre+"';";
		
//		out.println(busca);
	
		}
		else {
		String msg = "El usuario y password no coinciden";
		out.println(msg);
		response.sendRedirect(request.getContextPath()+"/errorpage.jsp?error="+msg );
		}	


		 

	 }

	 catch(Exception e){

			out.println("Ocurrio un error en main:"+e);

	 }
	
  }

}


